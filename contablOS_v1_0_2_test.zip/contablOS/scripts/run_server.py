import uvicorn
from pathlib import Path
if __name__ == '__main__':
    uvicorn.run('backend.main:app', host='0.0.0.0', port=8010, reload=False)
